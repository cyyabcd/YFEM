function [sigmaBase, sigmaDivDivBase, uBase, Dof] = CalculateSigmaBaseOnElement(elementInfo, P3Base3dLambda, P1Base3dLambda, symmetricTensorBase)
dofNum = 120;
%% 笛卡尔坐标下基函数
% lambda
lambdaToCartesian = CalculateLambda(elementInfo);
charLambdaToCartesian = cell(4,1);
for i = 1:4
    charLambdaToCartesian{i,1} = string(lambdaToCartesian(i));
end

uBase = sym(zeros(1, size(P1Base3dLambda,1)));
for i = 1:size(P1Base3dLambda,1)
    uBase(i) = expand(subs(P1Base3dLambda(i), {sym('lambda1'), sym('lambda2'), sym('lambda3'), sym('lambda4')}, {lambdaToCartesian(1),lambdaToCartesian(2),lambdaToCartesian(3),lambdaToCartesian(4)}));
end

% 基函数
P3Base = sym(zeros(size(P3Base3dLambda,1),1));
dP3Base = sym(zeros(size(P3Base3dLambda,1),3));
ddP3Base = sym(zeros(size(P3Base3dLambda,1),6));
for i = 1:size(P3Base3dLambda,1)
    P3Base(i) = vpa(expand(subs(P3Base3dLambda(i), {sym('lambda1'), sym('lambda2'), sym('lambda3'), sym('lambda4')}, {lambdaToCartesian(1),lambdaToCartesian(2),lambdaToCartesian(3),lambdaToCartesian(4)})));
    dP3Base(i,1) = diff(P3Base(i),sym('x'));
    dP3Base(i,2) = diff(P3Base(i),sym('y'));
    dP3Base(i,3) = diff(P3Base(i),sym('z'));
    ddP3Base(i,1) = diff(dP3Base(i,1),sym('x'));
    ddP3Base(i,2) = diff(dP3Base(i,1),sym('y'));
    ddP3Base(i,3) = diff(dP3Base(i,1),sym('z'));
    ddP3Base(i,4) = diff(dP3Base(i,2),sym('y'));
    ddP3Base(i,5) = diff(dP3Base(i,2),sym('z'));
    ddP3Base(i,6) = diff(dP3Base(i,3),sym('z'));
end

%% 导数
Base = sym(zeros(3,3,dofNum));
divBase = sym(zeros(3,dofNum));
divDivBase = sym(zeros(1,dofNum));
for i = 1:6
    for j = 1:20
        Base(:,:,20*(i-1)+j)= P3Base(j)*symmetricTensorBase(:,:,i);
        divBase(:,20*(i-1)+j) = dP3Base(j,:)*symmetricTensorBase(:,:,i);
        divDivBase(20*(i-1)+j) = sum(sum([ddP3Base(j,1) ddP3Base(j,2) ddP3Base(j,3);ddP3Base(j,2) ddP3Base(j,4) ddP3Base(j,5);ddP3Base(j,3) ddP3Base(j,5) ddP3Base(j,6)].*symmetricTensorBase(:,:,i)));
    end
end

%% 自由度
Dof = CreateDof(elementInfo, charLambdaToCartesian);

%%
M = CalculateDofOfBase(Dof,Base,divBase,elementInfo);
%% 求系数
invM = inv(M);
invM = invM';
%% 真实的基
sigmaBase = sym(zeros(3,3,dofNum));
% realDivBase = sym(zeros(3, dofNum));
sigmaDivDivBase = sym(zeros(1, dofNum));
for i = 1:dofNum
    for j = 1:dofNum
        sigmaBase(:,:,i) = sigmaBase(:,:,i)+ invM(i,j)*Base(:,:,j);
%         realDivBase(:,i) = realDivBase(:,i)+ invM(i,j)*divBase(:,j);
        sigmaDivDivBase(i) = sigmaDivDivBase(i) + invM(i,j)*divDivBase(j);
    end
end

end

