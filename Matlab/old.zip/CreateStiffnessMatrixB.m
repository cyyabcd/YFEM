function M = CreateStiffnessMatrixB(sigmaDivDivBase, uBase, elementInfo)
dofNum1 = size(sigmaDivDivBase, 2);
dofNum2 = size(uBase, 2);
M = zeros(dofNum1, dofNum2);
for i = 1:dofNum1
    for j = 1:dofNum2
        M(i,j) = elementInfo.volume*GaussIntegralAverage3dElement(sigmaDivDivBase(i)*uBase(j), elementInfo.nodes);
    end
end
end

