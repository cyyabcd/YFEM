a = Multinomials(2, 2, 4);
b = Multinomials(2, 2, 1);
c = Multinomials(2, 1, 2);
a.coefficient = [1 2 3 4 5 6;7 8 9 10 11 12;1 2 3 4 5 6;7 8 9 10 11 12];
b.coefficient = [7 8 9 10 11 12];
c.coefficient = [1 1 0; 0 1 0];
% a.substitute(c)
a.IntegralOnCube([0 0; 1 0], 1)
a.IntegralAverageOnSimplex([0 0; 1 0; 0 1], 2)
a.Evaluation([1 1], 1:3)