function M = CreateStiffnessMatrixC(uBase, elementInfo)
dofNum = size(uBase, 2);
M = zeros(dofNum, dofNum);
for i = 1:dofNum
    for j = 1:dofNum
        M(i,j) = elementInfo.volume*GaussIntegralAverage3dElement(uBase(i)*uBase(j), elementInfo.nodes);
    end
    
end
end