%%
dofNum = 120;

N = 1;
%% 几何信息
[elementList, nodeList] = TetrahedronMesh(N);

%% P3重心坐标下基函数
lambda = sym('lambda%d', [4,1]);
[P3Base3dLambda, P3Dof3d] = CreatePnBaseAndDof(lambda,3,3);

%% 笛卡尔坐标下基函数
% lambda
lambdaToCartesian = CalculateLambda(elementInfo);
charLambdaToCartesian = cell(4,1);
for i = 1:4
    charLambdaToCartesian{i,1} = string(lambdaToCartesian(i));
end

% 基函数
P3Base = sym(zeros(size(P3Base3dLambda,1),1));
for i = 1:size(P3Base3dLambda,1)
    P3Base(i) = expand(subs(P3Base3dLambda(i), {sym('lambda1'), sym('lambda2'), sym('lambda3'), sym('lambda4')}, {lambdaToCartesian(1),lambdaToCartesian(2),lambdaToCartesian(3),lambdaToCartesian(4)}));
end
dP3Base = sym(zeros(size(P3Base3dLambda,1),3));
ddP3Base = sym(zeros(size(P3Base3dLambda,1),6));
for i = 1:20
    dP3Base(i,1) = diff(P3Base(i),sym('x'));
    dP3Base(i,2) = diff(P3Base(i),sym('y'));
    dP3Base(i,3) = diff(P3Base(i),sym('z'));
end
for i = 1:20
    ddP3Base(i,1) = diff(dP3Base(i,1),sym('x'));
    ddP3Base(i,2) = diff(dP3Base(i,1),sym('y'));
    ddP3Base(i,3) = diff(dP3Base(i,1),sym('z'));
    ddP3Base(i,4) = diff(dP3Base(i,2),sym('y'));
    ddP3Base(i,5) = diff(dP3Base(i,2),sym('z'));
    ddP3Base(i,6) = diff(dP3Base(i,3),sym('z'));
end
% % TestP3 = zeros(20);
% % for i = 1:20
% %     for j = 1:20
% %        TestP3(i,j) = double(P3Dof3d{i,1}(P3Base3d(j,1)));
% %     end
% % end

% 对称矩阵基 symmetricTensorBase(:,:,i) 是第i个基
symmetricTensorBase = CreateSymmetricTensorBase();

% 
Base = sym(zeros(3,3,dofNum));
divBase = sym(zeros(3,dofNum));
divDivBase = sym(zeros(1,dofNum));
for i = 1:6
    for j = 1:20
        Base(:,:,20*(i-1)+j)= P3Base(j)*symmetricTensorBase(:,:,i);
        divBase(:,20*(i-1)+j) = dP3Base(j,:)*symmetricTensorBase(:,:,i);
        divDivBase(20*(i-1)+j) = sum(sum([ddP3Base(i,1) ddP3Base(i,2) ddP3Base(i,3);ddP3Base(i,2) ddP3Base(i,4) ddP3Base(i,5);ddP3Base(i,3) ddP3Base(i,5) ddP3Base(i,6)].*symmetricTensorBase(:,:,i)));
    end
end

%% 自由度
Dof = CreateDof(elementInfo, charLambdaToCartesian);

%%
M = CalculateDofOfBase(Dof,Base,divBase,elementInfo);
M = M.*(abs(M)>1e-8);
%% 求系数
invM = inv(M);
invM = invM.*(abs(invM)>1e-8);
invM = invM';
%% 真实的基
realBase = sym(zeros(3,3,dofNum));
realDivBase = sym(zeros(3, dofNum));
realDivDivBase = sym(zeros(1, dofNum));
for i = 1:dofNum
    for j = 1:dofNum
        realBase(:,:,i) = realBase(:,:,i)+ invM(i,j)*vpa(Base(:,:,j));
        realDivBase(:,i) = realDivBase(:,i)+ invM(i,j)*vpa(divBase(:,j));
        realDivDivBase(i) = realDivDivBase(i) + invM(i,j)*vpa(divDivBase(j));
    end
end

% TM = CalculateDofOfBase(Dof,realBase,realDivBase,elementInfo);


M = CreateStiffnessMatrixAOnElement(realBase, elementInfo);