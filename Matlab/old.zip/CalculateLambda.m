function lambda = CalculateLambda(elementInfo)
    syms x y z
    nodes = elementInfo.nodes;
    in = [1 x y z];
    s = det([ones(4,1), elementInfo.nodes]);
    lambda1 = det([in; 1 nodes(2,:); 1 nodes(3,:); 1 nodes(4,:)])/s;
    lambda2 = det([1 nodes(1,:); in; 1 nodes(3,:); 1 nodes(4,:)])/s;
    lambda3 = det([1 nodes(1,:); 1 nodes(2,:); in; 1 nodes(4,:)])/s;
    lambda4 = det([1 nodes(1,:); 1 nodes(2,:); 1 nodes(3,:); in])/s;
    lambda = [lambda1, lambda2, lambda3, lambda4];
end

