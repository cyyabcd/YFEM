%%
dofNum = 120;

N = 16;
%% 几何信息
[elementList, nodeList] = TetrahedronMesh(N);
nodeNum = (N+1)^3;
elementNum = 6*N^3;

%% P3重心坐标下基函数
lambda = sym('lambda%d', [4,1]);
[P3Base3dLambda, ~] = CreatePnBaseAndDof(lambda,3,3);
[P1Base3dLambda, ~] = CreatePnBaseAndDof(lambda,1,3);
P1Base3dLambda = P1Base3dLambda([4,3,2,1]);
%% 对称矩阵基 symmetricTensorBase(:,:,i) 是第i个基
symmetricTensorBase = CreateSymmetricTensorBase();

%% 单元上刚度矩阵
A = zeros(dofNum, dofNum, 6);
B = zeros(dofNum, 4, 6);
C = zeros(4, 4, 6);
elementInfo = cell(6,1);
sigmaBase = cell(6,1);
sigmaDivDivBase = cell(6,1);
uBase = cell(6,1);
Dof = cell(6,1);
parfor i = 1:6
    elementInfo{i,1} = CreateGeometryInformationOnElement(elementList(i,:), nodeList);
end
parfor i = 1:6
    [sigmaBase{i,1}, sigmaDivDivBase{i,1}, uBase{i,1}, Dof{i,1}] = CalculateSigmaBaseOnElement(elementInfo{i,1}, P3Base3dLambda, P1Base3dLambda, symmetricTensorBase);
end

parfor i = 1:6
    B(:,:,i) = CreateStiffnessMatrixB(sigmaDivDivBase{i,1}, uBase{i,1}, elementInfo{i,1});
end
parfor i = 1:6
    C(:,:,i) = CreateStiffnessMatrixC(uBase{i,1}, elementInfo{i,1});
end
parfor i = 1:6
    A(:,:,i) = CreateStiffnessMatrixA(sigmaBase{i,1}, elementInfo{i,1});
end
%% 单刚到总刚
[edgeNum, faceNum, edgeMatrix, faceMatrix] = CreateEdgeAndFaceNum(elementList);
[edgeList, faceList, elementToEdge, elementToFace] = CreateEdgeAndFace(elementList, edgeNum, faceNum, edgeMatrix, faceMatrix);
[elementToDof, dofNum] = CreateElementToDof(elementList, edgeNum, faceNum, elementToEdge, elementToFace);
[elementToDofu, dofNumu] = CreateElementToDofu(elementList);
[LHS, RHS] = CreateStiffnessMatrixOnMesh(A, B, C, elementToDof, elementToDofu);
% fLHS = full(LHS);
% fRHS = full(RHS);
eign = 1./eigs(RHS, LHS)