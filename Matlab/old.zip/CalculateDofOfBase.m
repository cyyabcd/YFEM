function M = CalculateDofOfBase(Dof, Base, divBase,elementInfo)
dofNum = 120;
M = zeros(dofNum);
for i = 1:96
    for j = 1:dofNum
        M(i,j) = Dof{i,1}(Base(:,:,j));
    end
end
for i = 97:dofNum
    for j = 1:dofNum
        M(i,j) = Dof{i,1}(divBase(:,j));
    end
end
end

