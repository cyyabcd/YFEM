function M = CreateStiffnessMatrixA(realBase, elementInfo)
dofNum = size(realBase, 3);
M = zeros(dofNum);
for i = 1:dofNum
    for j = 1:dofNum
        M(i,j) = elementInfo.volume*GaussIntegralAverage3dElement(sum(sum(realBase(:,:,i).*realBase(:,:,j))), elementInfo.nodes);
    end
end

