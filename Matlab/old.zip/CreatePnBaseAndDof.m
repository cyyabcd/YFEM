function [PnBasekd, PnDof] = CreatePnBaseAndDof(lambda, n, k)
% k维下Pn元的基, k = 1, 2, 3
baseFace = sym(zeros(k+1, n+1));
PnBasekd = sym(ones(nchoosek(n+k,k),1));
PnDof = cell(nchoosek(n+k,k),1);
for i = 1:k+1
    for j = 1:n+1
        baseFace(i,j) = lambda(i) - (j-1)/n;
    end
end
t = 0;
if k == 1
    for i1 = 0:n
        i2 = n-i1;
        t = t + 1;
        for j = i1+1:n
            PnBasekd(t) = PnBasekd(t)*baseFace(1,j+1);
        end
        for j = i2+1:n
            PnBasekd(t) = PnBasekd(t)*baseFace(2,j+1);
        end
    end
elseif k == 2
    for i1 = 0:n
        for i2 = 0:n-i1
            i3 = n-i1-i2;
            t = t + 1;
            for j = 0:i1-1
                PnBasekd(t) = PnBasekd(t)*baseFace(1,j+1);
            end
            for j = 0:i2-1
                PnBasekd(t) = PnBasekd(t)*baseFace(2,j+1);
            end
            for j = 0:i3-1
                PnBasekd(t) = PnBasekd(t)*baseFace(3,j+1);
            end
            
        end
    end
elseif k == 3
    for i1 = 0:n
        for i2 = 0:n-i1
            for i3 = 0:n-i1-i2
                i4 = n-i1-i2-i3;
                t = t + 1;
                for j = 0:i1-1
                    PnBasekd(t) = PnBasekd(t)*baseFace(1,j+1);
                end
                for j = 0:i2-1
                    PnBasekd(t) = PnBasekd(t)*baseFace(2,j+1);
                end
                for j = 0:i3-1
                    PnBasekd(t) = PnBasekd(t)*baseFace(3,j+1);
                end
                for j = 0:i4-1
                    PnBasekd(t) = PnBasekd(t)*baseFace(4,j+1);
                end
                factor = subs(PnBasekd(t), {sym('lambda1'), sym('lambda2'), sym('lambda3'), sym('lambda4')}, {i1/n,i2/n,i3/n,i4/n});
                PnBasekd(t) = PnBasekd(t)/factor;
                PnDof{t} = @(fun) subs(fun, {sym('lambda1'), sym('lambda2'), sym('lambda3'), sym('lambda4')}, {i1/n,i2/n,i3/n,i4/n});
            end
        end
    end
end
end

